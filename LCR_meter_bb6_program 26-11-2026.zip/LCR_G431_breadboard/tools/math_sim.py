"""Bench-free check of the firmware maths (lcr.c / calib.c / phase_cmp.c), mirrored in float32.

Synthetic ADC data: VS = 0.5 V sine on VMID (1.65 V), VX = VS * Z/(Z+Rref) (+ optional stray C across
the DUT and series lead resistance), 12-bit quantisation and noise, exactly WAVE_N samples per period.
Checks: recovered Z, R/L/C decision and sign, auto-range choice, open/short compensation, comparator
phase pairing with 16-bit counter wrap.
"""
import math
import numpy as np

rng = np.random.default_rng(1)
N, M = 64, 16
RREF = [100.0, 1e3, 1e4, 4.7e4, 1e6]
H_EDGE, HYST, REACTIVE_MIN, Z_OPEN, Z_SHORT = 0.02, 0.35, 0.10, 20e6, 0.5
k = np.arange(N)
COS = np.cos(2 * np.pi * k / N).astype(np.float32)
SIN = np.sin(2 * np.pi * k / N).astype(np.float32)


def adc_block(z_dut, rref, f, stray_c=0.0, lead_r=0.0, noise_lsb=1.0, phase0=0.7):
    w = 2 * math.pi * f
    z = z_dut + lead_r
    if stray_c:
        zc = 1 / (1j * w * stray_c)
        z = z * zc / (z + zc) if np.isfinite(z) else zc
    h = z / (z + rref) if np.isfinite(z) else 1.0
    n = np.arange(N * M)
    vs = 0.5 * np.exp(1j * (2 * np.pi * n / N + phase0))
    vx = vs * h
    to = lambda v: np.clip(np.round((1.65 + v.real) / 3.3 * 4095 + rng.normal(0, noise_lsb, v.shape)), 0, 4095).astype(np.uint16)
    return to(vs), to(vx)


def measure_raw(z_dut, rg, f, reps=2, **kw):
    acc = np.zeros(4, np.float32)
    for _ in range(reps):
        a, b = adc_block(z_dut, RREF[rg], f, **kw)
        kk = np.arange(N * M) & (N - 1)
        acc += np.array([np.sum(a * COS[kk], dtype=np.float32), -np.sum(a * SIN[kk], dtype=np.float32),
                         np.sum(b * COS[kk], dtype=np.float32), -np.sum(b * SIN[kk], dtype=np.float32)], np.float32)
    S = complex(acc[0], acc[1]); X = complex(acc[2], acc[3])
    H = X / S
    zr = RREF[rg] * H / (1 - H) if abs(1 - H) > 0 else complex(math.inf)
    st = "LOW" if abs(H) < H_EDGE else "HIGH" if abs(1 - H) < H_EDGE else "OK"
    return H, zr, st


def cal_apply(zm, zo=None, zs=0j):
    if zo is not None:
        den = zo - zm
        return (zm - zs) * (zo - zs) / den if abs(den) > 1e-6 * abs(zo) else complex(math.inf)
    return zm - zs


def best_range(mag):
    if not math.isfinite(mag):
        return 4
    return min(range(5), key=lambda i: abs(math.log10(mag / RREF[i])))


def auto(z_dut, f, start=2, cal=None, **kw):
    rg = start
    for _ in range(5):
        H, zr, st = measure_raw(z_dut, rg, f, **kw)
        z = cal_apply(zr, *cal[rg]) if cal else zr
        nxt = rg
        if st == "HIGH": nxt = rg + 1
        elif st == "LOW": nxt = rg - 1
        else:
            mag = abs(z); b = best_range(mag)
            if b != rg:
                cur = abs(math.log10(mag / RREF[rg])) if math.isfinite(mag) else math.inf
                bst = abs(math.log10(mag / RREF[b])) if math.isfinite(mag) else 0
                if cur - bst > HYST: nxt = b
        if nxt < 0: return rg, "SHORT", z
        if nxt > 4: return rg, "OPEN", z
        if nxt == rg: break
        rg = nxt
    return rg, st, z


def classify(z, f):
    mag = abs(z)
    if not math.isfinite(mag) or mag > Z_OPEN: return "OPEN", None
    if mag < Z_SHORT: return "SHORT", None
    w = 2 * math.pi * f
    if abs(z.imag) < REACTIVE_MIN * mag: return "R", z.real
    if z.imag > 0: return "L", z.imag / w
    return "C", -1 / (w * z.imag)


fails = 0
def check(name, ok, info):
    global fails
    fails += 0 if ok else 1
    print(f"{'PASS' if ok else 'FAIL'}  {name:34s} {info}")

# 1) ideal parts across the ranges, both frequencies
cases = [("R 10", 10, None), ("R 1k", 1e3, None), ("R 470k", 4.7e5, None), ("R 2M", 2e6, None),
         ("C 1nF", None, ("C", 1e-9)), ("C 100nF", None, ("C", 1e-7)), ("C 10uF", None, ("C", 1e-5)),
         ("L 10mH", None, ("L", 1e-2)), ("L 100mH", None, ("L", 0.1)), ("L 1mH @10k", None, ("L", 1e-3))]
for name, r, lc in cases:
    f = 10e3 if "@10k" in name else 1e3
    w = 2 * math.pi * f
    if r is not None:
        z, kind, true = complex(r, 0), "R", r
    elif lc[0] == "C":
        z, kind, true = 1 / (1j * w * lc[1]), "C", lc[1]
    else:
        z, kind, true = complex(0.5, w * lc[1]), "L", lc[1]     # coil with 0.5 ohm winding resistance
    rg, st, zm = auto(z, f)
    got_kind, val = classify(zm, f) if st == "OK" else (st, None)
    err = abs(val - true) / true * 100 if val else float('nan')
    check(name, got_kind == kind and err < 1.0, f"range {RREF[rg]:g}  kind {got_kind}  value {val:.5g}  err {err:.3f}%")

# 2) open / short ends
rg, st, _ = auto(complex(math.inf), 1e3)
check("nothing connected", st == "OPEN", f"status {st} on {RREF[rg]:g}")
rg, st, zm = auto(complex(0.01, 0), 1e3)
check("leads shorted", st in ("SHORT", "LOW") or classify(zm, 1e3)[0] == "SHORT", f"status {st} on {RREF[rg]:g}, |Z|={abs(zm):.3g}")

# 3) compensation: 12 pF stray across the clips + 0.3 ohm leads; 22 pF part on the 1M range, 4.7 ohm on 100R
f, cs, rl = 1e3, 12e-12, 0.3
cal = []
for rg in range(5):
    _, zo, sto = measure_raw(complex(math.inf), rg, f, stray_c=cs, lead_r=rl, noise_lsb=0.3)
    _, zs, sts = measure_raw(0j, rg, f, stray_c=cs, lead_r=rl, noise_lsb=0.3)
    cal.append((zo if abs(1 - (zo / (zo + RREF[rg]))) > 0.002 else None, zs if abs(zs / (zs + RREF[rg])) > 0.002 else 0j))
w = 2 * math.pi * f
for name, z, kind, true in [("22pF on 1M with stray", 1 / (1j * w * 22e-12), "C", 22e-12),
                            ("4.7 ohm with leads", complex(4.7, 0), "R", 4.7)]:
    rg, st, zraw = auto(z, f, stray_c=cs, lead_r=rl, noise_lsb=0.3)
    _, val_raw = classify(zraw, f)
    rg, st, zc = auto(z, f, cal=cal, stray_c=cs, lead_r=rl, noise_lsb=0.3)
    k2, val = classify(zc, f)
    err_raw = abs(val_raw - true) / true * 100
    err = abs(val - true) / true * 100
    check(name, k2 == kind and err < 2.0 and err < err_raw, f"uncal err {err_raw:.1f}% -> cal err {err:.2f}%")

# 4) comparator phase pairing (16-bit counter at 32 MHz, 1 kHz -> T = 32000 counts)
def cmp_phase(phi_true_deg, T=32000.0, periods=16, t0=51234.0, poll=0):
    ev = []
    for p in range(periods + 3):
        ts = t0 + p * T
        tx = ts - phi_true_deg / 360 * T          # phi = 2pi (tS - tX)/T
        ev.append((ts, 1)); ev.append((tx, 2))
    ev.sort()
    if poll:   # both flags seen in the same poll pass: the C loop handles CH1 before CH2
        ev.sort(key=lambda e: (int(e[0] // poll), e[1]))
    last_s = prev_s = 0; have_s = n_per = n_pair = 0; sum_per = 0; pend = []; sc = ss = 0.0
    for t, ch in ev:
        c = int(t) & 0xFFFF
        if ch == 1:
            prev_s, last_s = last_s, c
            if have_s: sum_per += (last_s - prev_s) & 0xFFFF; n_per += 1
            have_s += 1
        elif n_per > 0:
            pend.append(c)
        if n_per and pend and have_s >= 2:
            Tm = sum_per / n_per
            for x in pend:
                d = (x - last_s) & 0xFFFF
                if d >= Tm: d = (x - prev_s) & 0xFFFF
                if d < Tm:
                    ph = -2 * math.pi * d / Tm; sc += math.cos(ph); ss += math.sin(ph); n_pair += 1
            pend = []
        if n_pair >= periods: break
    return math.degrees(math.atan2(ss, sc))
for ph in (-89.0, -30.0, 0.0, 45.0, 179.0):
    for poll in (0, 5000):
        got = cmp_phase(ph, poll=poll)
        check(f"comparator phase {ph:+.0f} deg poll={poll}", abs((got - ph + 180) % 360 - 180) < 0.05, f"got {got:+.3f}")
got = cmp_phase(60.0, T=3200.0)   # 10 kHz
check("comparator phase +60 deg @10k (1 count = 0.11 deg)", abs(got - 60.0) < 0.12, f"got {got:+.3f}")

print("\nALL PASS" if fails == 0 else f"\n{fails} FAILED")
