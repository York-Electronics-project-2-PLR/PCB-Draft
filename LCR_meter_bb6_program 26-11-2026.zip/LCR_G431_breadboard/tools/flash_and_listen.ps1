# Copies a .bin to the Nucleo drive (optional) and records what the program prints on the ST-LINK serial port.
# usage: flash_and_listen.ps1 -Port COM4 [-Bin <file.bin>] [-Drive E:\] [-Seconds 12] [-Send "info"] [-SendAfter 8]
param(
    [string]$Port = 'COM4',
    [string]$Bin = '',
    [string]$Drive = 'E:\',
    [int]$Seconds = 12,
    [string]$Send = '',
    [int]$SendAfter = 8
)
$sp = New-Object System.IO.Ports.SerialPort $Port, 115200, 'None', 8, 'One'
$sp.ReadTimeout = 200
$sp.DtrEnable = $true
$sp.Open()
$sb = New-Object System.Text.StringBuilder
$t0 = Get-Date
if ($Bin) {
    Copy-Item -LiteralPath $Bin -Destination $Drive -Force
    Write-Output ("copied to {0} after {1:N1} s" -f $Drive, ((Get-Date) - $t0).TotalSeconds)
}
$end = (Get-Date).AddSeconds($Seconds)
$sent = $false
while ((Get-Date) -lt $end) {
    try {
        $s = $sp.ReadExisting()
        if ($s) { [void]$sb.Append($s) }
    } catch {
        Write-Output ("serial read error: " + $_.Exception.Message)
        break
    }
    if ($Send -and -not $sent -and ((Get-Date) - $t0).TotalSeconds -ge $SendAfter) {
        foreach ($cmd in $Send.Split(';')) { $sp.Write($cmd + "`r"); Start-Sleep -Milliseconds 300 }
        $sent = $true
    }
    Start-Sleep -Milliseconds 40
}
$sp.Close()
Write-Output ("--- {0} characters received on {1}" -f $sb.Length, $Port)
# measurement rows (CSV, start with the frequency) are only counted; the last few are shown
$lines = $sb.ToString() -split "`r?`n"
$csv = @($lines | Where-Object { $_ -match '^\d+,' })
$lines | Where-Object { $_ -notmatch '^\d+,' -and $_.Trim() -ne '' } | ForEach-Object { Write-Output $_ }
Write-Output ("--- {0} measurement rows; statuses: {1}" -f $csv.Count, (($csv | ForEach-Object { ($_ -split ',')[12] } | Group-Object | ForEach-Object { "$($_.Name) x$($_.Count)" }) -join ', '))
$csv | Select-Object -Last 4 | ForEach-Object { Write-Output $_ }
if (Test-Path (Join-Path $Drive 'FAIL.TXT')) {
    Write-Output '--- FAIL.TXT on the drive:'
    Get-Content (Join-Path $Drive 'FAIL.TXT')
}
