# Checks the block averaging used in lcr.c (lcr_measure_range) in float32:
# every DMA block starts at a random point of the 64-point sine table, so its phasors are rotated.
#   old method: add the phasors of all blocks, then H = sum(X) / sum(S)      -> amplitude can cancel
#   new method: H = sum(X conj S) / sum(|S|^2), amplitudes from sum(|.|^2)   -> independent of the rotation
# usage: python block_phase_sim.py
import numpy as np

rng = np.random.default_rng(1)
N, PER = 64, 16
n = np.arange(N * PER)
c = np.cos(2 * np.pi * (n % N) / N).astype(np.float32)
s = np.sin(2 * np.pi * (n % N) / N).astype(np.float32)

def block(h, start, noise=1.0):
    """ADC codes of VS and VX for one block that starts 'start' table steps into the period."""
    ph = 2 * np.pi * ((n + start) % N) / N
    vs = 2048 + 600 * np.sin(ph)
    vx = 2048 + 600 * abs(h) * np.sin(ph + np.angle(h))
    vs = np.round(vs + rng.normal(0, noise, n.size)).astype(np.float32)
    vx = np.round(vx + rng.normal(0, noise, n.size)).astype(np.float32)
    k = np.float32(2.0 / n.size)
    S = np.complex64((vs * c).sum() - 1j * (vs * s).sum()) * k
    X = np.complex64((vx * c).sum() - 1j * (vx * s).sum()) * k
    return S, X

worst_old_amp = 1.0
ok = True
for h in (0.5 + 0j, 0.9 - 0.1j, 0.02 + 0.01j, 0.3 + 0.4j):
    worst_new = 0.0
    for trial in range(200):
        reps = 2 if trial % 2 else 8
        starts = rng.integers(0, N, reps)
        blocks = [block(h, st) for st in starts]
        S_sum = sum(b[0] for b in blocks); X_sum = sum(b[1] for b in blocks)
        pss = sum(abs(b[0]) ** 2 for b in blocks)
        pxs = sum(b[1] * np.conj(b[0]) for b in blocks)
        h_new = pxs / pss
        vs_new = np.sqrt(pss / reps)
        worst_new = max(worst_new, abs(h_new - h) / abs(h))
        worst_old_amp = min(worst_old_amp, abs(S_sum) / reps / 600.0)
        assert abs(vs_new - 600) < 3, vs_new
    # with 1 LSB of noise a VX of only ~13 codes (|H| = 0.02) cannot be better than about 1 %; that is noise, not the method
    limit = 1e-3 if abs(h) >= 0.3 else 2e-2
    print('new method, H = %-12s worst relative error over 200 trials = %.2e (limit %.0e)' % (h, worst_new, limit))
    ok = ok and worst_new < limit
print('old method: smallest "VS amplitude" seen = %.1f %% of the true amplitude' % (100 * worst_old_amp))
print('PASS' if ok else 'FAIL')
raise SystemExit(0 if ok else 1)
