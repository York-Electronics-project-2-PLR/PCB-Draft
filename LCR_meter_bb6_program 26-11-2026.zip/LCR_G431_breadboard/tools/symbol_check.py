"""Static check without a compiler: every HAL/CMSIS identifier and handle member used by the
firmware sources must be defined somewhere in the bundled ST/ARM headers (catches typos and
names that do not exist on the G4 family)."""
import glob
import os
import re
import sys

root = sys.argv[1]
os.chdir(root)
mine = [f for f in glob.glob('Core/Src/*.c') + glob.glob('Core/Inc/*.h')
        if 'system_stm32' not in f and 'hal_conf' not in f]
lib_text = ""
for f in glob.glob('Drivers/**/*.h', recursive=True) + ['Core/Inc/stm32g4xx_hal_conf.h']:
    lib_text += open(f, encoding='utf-8', errors='ignore').read()
own_text = "".join(open(f, encoding='utf-8').read() for f in mine)
own_defs = set(re.findall(r'#define\s+(\w+)', own_text)) | set(re.findall(r'\b(\w+)\s*\(', own_text))


def strip(t):
    t = re.sub(r'/\*.*?\*/', '', t, flags=re.S)
    t = re.sub(r'//.*', '', t)
    return re.sub(r'"(?:\\.|[^"\\])*"', '""', t)


ids, members = set(), set()
for f in mine:
    t = strip(open(f, encoding='utf-8').read())
    ids |= set(re.findall(r'\b(__HAL_\w+|HAL_\w+|[A-Z][A-Z0-9]*_[A-Z0-9_]+)\b', t))
    ids |= set(re.findall(r'\b(GPIO[A-Z]|DMA1_Channel\d|ADC\d|DAC\d|TIM\d+|USART\d|DWT|CoreDebug|SystemCoreClock)\b', t))
    members |= set(re.findall(r'\.Init\.(\w+)', t)) | set(re.findall(r'\.(PLL\w*|DAC_\w+|AdvFeatureInit|TypeErase|Banks|Page|NbPages)\s*=', t))
    members |= set(re.findall(r'\b(?:g|c|ch|mm|m|ic|osc|clk|er)\.(\w+)\s*=', t))

missing = [i for i in sorted(ids) if i not in own_defs and not re.search(r'\b' + re.escape(i) + r'\b', lib_text)]
miss_m = [m for m in sorted(members) if not re.search(r'\b' + re.escape(m) + r'\s*;', lib_text)]
print(f"{len(ids)} identifiers checked, not found in headers: {missing}")
print(f"{len(members)} struct members checked, not found as a field: {miss_m}")
