/*
 * board.c - clock tree and peripheral set-up.
 *
 *   TIM6 TRGO --+--> DAC1 CH1 (PA4)  <- DMA1 CH2, circular, 64-point sine table
 *               +--> ADC1 (PA0, VS) + ADC2 (PA7, VX), dual regular simultaneous
 *                    -> one 32-bit word per trigger -> DMA1 CH1 -> buffer
 *
 * DAC and ADC run off the same trigger, so every acquisition holds exactly
 * WAVE_N samples per excitation period (coherent sampling, no window needed).
 */
#include "board.h"
#include "config.h"
#include "lcd1602.h"
#include <string.h>

ADC_HandleTypeDef  hadc1, hadc2;
DAC_HandleTypeDef  hdac1;
DMA_HandleTypeDef  hdma_adc1, hdma_dac1;
TIM_HandleTypeDef  htim1, htim6;
UART_HandleTypeDef huart2;

static const uint32_t s_tim6_arr[NUM_FREQS] = FREQ_TIM6_ARR;
/* ADC clock = HCLK/4 = 32 MHz. A conversion = sampling + 12.5 cycles and must
 * fit in one trigger period: 1 kHz -> 15.6 us (247.5 + 12.5 = 8.1 us),
 * 10 kHz -> 1.56 us (24.5 + 12.5 = 1.16 us). Long sampling helps the
 * high-impedance VX node on the 47k / 1M ranges.                            */
static const uint32_t s_adc_smp[NUM_FREQS] = { ADC_SAMPLETIME_247CYCLES_5, ADC_SAMPLETIME_24CYCLES_5 };

void board_error(const char *where)
{
    __disable_irq();
    if (lcd_ready()) {                                   /* lcd_line() only needs delay_us(), which works with interrupts off */
        lcd_line(0, "FATAL ERROR:");
        lcd_line(1, where);
    }
    if (huart2.Instance != NULL) {
        static const char msg[] = "\r\nFATAL: ";
        HAL_UART_Transmit(&huart2, (uint8_t *)msg, sizeof msg - 1, 100);
        HAL_UART_Transmit(&huart2, (uint8_t *)where, (uint16_t)strlen(where), 100);
    }
    for (;;) {
    }
}

#define CHECK(x) do { if ((x) != HAL_OK) board_error(#x); } while (0)

/* HSI16 / 4 * 64 / 2 = 128 MHz. Voltage range 1 (normal), 4 flash wait states (<= 150 MHz). */
void board_clock_init(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    __HAL_RCC_SYSCFG_CLK_ENABLE();
    __HAL_RCC_PWR_CLK_ENABLE();                          /* PWR registers need their clock before the range is set */
    CHECK(HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1));
    osc.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    osc.HSIState = RCC_HSI_ON;
    osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    osc.PLL.PLLM = RCC_PLLM_DIV4;
    osc.PLL.PLLN = 64;
    osc.PLL.PLLP = RCC_PLLP_DIV2;
    osc.PLL.PLLQ = RCC_PLLQ_DIV2;
    osc.PLL.PLLR = RCC_PLLR_DIV2;
    CHECK(HAL_RCC_OscConfig(&osc));

    clk.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV1;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    CHECK(HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_4));
}

void delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (SystemCoreClock / 1000000u);
    while ((DWT->CYCCNT - start) < ticks) {
    }
}

static void gpio_init(void)
{
    GPIO_InitTypeDef g = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* safe levels before the pins become outputs: muxes disabled, address 0 */
    HAL_GPIO_WritePin(MUX_INH_PORT, MUX_INH_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOB, MUX_S0_PIN | MUX_S1_PIN | LCD_D4_PIN | LCD_D6_PIN | LCD_D7_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, MUX_S2_PIN | LCD_RS_PIN | LCD_E_PIN | LCD_D5_PIN, GPIO_PIN_RESET);

    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Pin = MUX_S0_PIN | MUX_S1_PIN | MUX_INH_PIN | LCD_D4_PIN | LCD_D6_PIN | LCD_D7_PIN;
    HAL_GPIO_Init(GPIOB, &g);
    g.Pin = MUX_S2_PIN | LCD_RS_PIN | LCD_E_PIN | LCD_D5_PIN;
    HAL_GPIO_Init(GPIOA, &g);

    g.Mode = GPIO_MODE_INPUT;
    g.Pull = GPIO_PULLUP;
    g.Pin = BTN_PIN;
    HAL_GPIO_Init(BTN_PORT, &g);

    /* analogue: DAC out, both ADC inputs, and PA5 / PA6 which solder bridges
     * SB2 / SB3 tie to PB7 / PA15 on the Nucleo - keep them high impedance */
    g.Mode = GPIO_MODE_ANALOG;
    g.Pull = GPIO_NOPULL;
    g.Pin = GPIO_PIN_0 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
    HAL_GPIO_Init(GPIOA, &g);

    /* TIM1 CH1 / CH2 capture inputs from the TLV3202 (push-pull outputs) */
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Alternate = GPIO_AF6_TIM1;
    g.Pin = GPIO_PIN_8 | GPIO_PIN_9;
    HAL_GPIO_Init(GPIOA, &g);

    /* USART2 to the ST-LINK virtual COM port */
    g.Pull = GPIO_PULLUP;
    g.Alternate = GPIO_AF7_USART2;
    g.Pin = GPIO_PIN_2 | GPIO_PIN_3;
    HAL_GPIO_Init(GPIOA, &g);
}

static void uart_init(void)
{
    __HAL_RCC_USART2_CLK_ENABLE();
    huart2.Instance = USART2;
    huart2.Init.BaudRate = UART_BAUD;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
    huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    CHECK(HAL_UART_Init(&huart2));
    HAL_NVIC_SetPriority(USART2_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
}

static void dma_init(void)
{
    __HAL_RCC_DMAMUX1_CLK_ENABLE();
    __HAL_RCC_DMA1_CLK_ENABLE();

    hdma_adc1.Instance = DMA1_Channel1;
    hdma_adc1.Init.Request = DMA_REQUEST_ADC1;            /* dual mode: master requests, data from ADC12 CDR */
    hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_adc1.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_adc1.Init.Mode = DMA_NORMAL;
    hdma_adc1.Init.Priority = DMA_PRIORITY_VERY_HIGH;
    CHECK(HAL_DMA_Init(&hdma_adc1));
    HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

    hdma_dac1.Instance = DMA1_Channel2;
    hdma_dac1.Init.Request = DMA_REQUEST_DAC1_CHANNEL1;
    hdma_dac1.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_dac1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_dac1.Init.MemInc = DMA_MINC_ENABLE;
    /* Word access is required: on the G4 the DAC sits directly on AHB2 and a 16-bit DMA write
     * to DHR12R1 ends in a DMA transfer error (TEIF), which switches the channel off - the DAC
     * then stays at 0 V. Found on the real board, 2026-11-25. The sine table is uint32_t. */
    hdma_dac1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_dac1.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    hdma_dac1.Init.Mode = DMA_CIRCULAR;
    hdma_dac1.Init.Priority = DMA_PRIORITY_HIGH;
    CHECK(HAL_DMA_Init(&hdma_dac1));
    /* no NVIC for the DAC channel: it free-runs, nothing to do per period */
}

static void tim6_init(void)
{
    TIM_MasterConfigTypeDef m = {0};

    __HAL_RCC_TIM6_CLK_ENABLE();
    htim6.Instance = TIM6;
    htim6.Init.Prescaler = 0;
    htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim6.Init.Period = s_tim6_arr[0];
    htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
    CHECK(HAL_TIM_Base_Init(&htim6));
    m.MasterOutputTrigger = TIM_TRGO_UPDATE;
    m.MasterOutputTrigger2 = TIM_TRGO2_RESET;
    m.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    CHECK(HAL_TIMEx_MasterConfigSynchronization(&htim6, &m));
}

static void tim1_init(void)
{
    TIM_IC_InitTypeDef ic = {0};

    __HAL_RCC_TIM1_CLK_ENABLE();
    htim1.Instance = TIM1;
    htim1.Init.Prescaler = 3;                 /* 32 MHz count: 1 kHz period = 32000 counts < 65536 */
    htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim1.Init.Period = 0xFFFF;
    htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim1.Init.RepetitionCounter = 0;
    htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    CHECK(HAL_TIM_IC_Init(&htim1));
    ic.ICPolarity = TIM_ICPOLARITY_RISING;
    ic.ICSelection = TIM_ICSELECTION_DIRECTTI;
    ic.ICPrescaler = TIM_ICPSC_DIV1;
    ic.ICFilter = 0xF;                        /* same digital filter delay on both channels -> cancels */
    CHECK(HAL_TIM_IC_ConfigChannel(&htim1, &ic, TIM_CHANNEL_1));
    CHECK(HAL_TIM_IC_ConfigChannel(&htim1, &ic, TIM_CHANNEL_2));
    CHECK(HAL_TIM_IC_Start(&htim1, TIM_CHANNEL_1));
    CHECK(HAL_TIM_IC_Start(&htim1, TIM_CHANNEL_2));
}

static void dac_init(void)
{
    DAC_ChannelConfTypeDef c = {0};

    __HAL_RCC_DAC1_CLK_ENABLE();
    hdac1.Instance = DAC1;
    CHECK(HAL_DAC_Init(&hdac1));
    c.DAC_HighFrequency = DAC_HIGH_FREQUENCY_INTERFACE_MODE_AUTOMATIC;
    c.DAC_DMADoubleDataMode = DISABLE;
    c.DAC_SignedFormat = DISABLE;
    c.DAC_SampleAndHold = DAC_SAMPLEANDHOLD_DISABLE;
    c.DAC_Trigger = DAC_TRIGGER_T6_TRGO;
    c.DAC_Trigger2 = DAC_TRIGGER_NONE;
    c.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;      /* drives the Sallen-Key input (R3) */
    c.DAC_ConnectOnChipPeripheral = DAC_CHIPCONNECT_EXTERNAL;
    c.DAC_UserTrimming = DAC_TRIMMING_FACTORY;
    CHECK(HAL_DAC_ConfigChannel(&hdac1, &c, DAC_CHANNEL_1));
    __HAL_LINKDMA(&hdac1, DMA_Handle1, hdma_dac1);
}

static void adc_common_fill(ADC_HandleTypeDef *h)
{
    h->Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;   /* 32 MHz (max 60 MHz) */
    h->Init.Resolution = ADC_RESOLUTION_12B;
    h->Init.DataAlign = ADC_DATAALIGN_RIGHT;
    h->Init.GainCompensation = 0;
    h->Init.ScanConvMode = ADC_SCAN_DISABLE;
    h->Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    h->Init.LowPowerAutoWait = DISABLE;
    h->Init.ContinuousConvMode = DISABLE;
    h->Init.NbrOfConversion = 1;
    h->Init.DiscontinuousConvMode = DISABLE;
    h->Init.SamplingMode = ADC_SAMPLING_MODE_NORMAL;
    h->Init.DMAContinuousRequests = DISABLE;             /* one DMA block per acquisition */
    h->Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    h->Init.OversamplingMode = DISABLE;
}

static uint32_t s_cur_smp;

/* Diagnostics: point ADC2 at another input (ADC_CHANNEL_4 = PA7 = VX is the normal one,
 * ADC_CHANNEL_17 = PA4 = the DAC output pin). Only call while no acquisition is running. */
void board_adc2_channel(uint32_t channel)
{
    ADC_ChannelConfTypeDef ch = {0};

    ch.Rank = ADC_REGULAR_RANK_1;
    ch.SamplingTime = s_cur_smp;
    ch.SingleDiff = ADC_SINGLE_ENDED;
    ch.OffsetNumber = ADC_OFFSET_NONE;
    ch.Offset = 0;
    ch.Channel = channel;
    CHECK(HAL_ADC_ConfigChannel(&hadc2, &ch));
}

static void adc_channels(uint32_t smp)
{
    ADC_ChannelConfTypeDef ch = {0};

    s_cur_smp = smp;
    ch.Rank = ADC_REGULAR_RANK_1;
    ch.SamplingTime = smp;
    ch.SingleDiff = ADC_SINGLE_ENDED;
    ch.OffsetNumber = ADC_OFFSET_NONE;
    ch.Offset = 0;
    ch.Channel = ADC_CHANNEL_1;          /* PA0 = VS */
    CHECK(HAL_ADC_ConfigChannel(&hadc1, &ch));
    ch.Channel = ADC_CHANNEL_4;          /* PA7 = VX */
    CHECK(HAL_ADC_ConfigChannel(&hadc2, &ch));
}

static void adc_init(void)
{
    ADC_MultiModeTypeDef mm = {0};

    __HAL_RCC_ADC12_CLK_ENABLE();

    hadc1.Instance = ADC1;                                /* master */
    adc_common_fill(&hadc1);
    hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T6_TRGO;
    hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
    CHECK(HAL_ADC_Init(&hadc1));

    mm.Mode = ADC_DUALMODE_REGSIMULT;                     /* VS and VX sampled at the same instant */
    mm.DMAAccessMode = ADC_DMAACCESSMODE_12_10_BITS;      /* ADC1 in bits 0-15, ADC2 in bits 16-31 */
    mm.TwoSamplingDelay = ADC_TWOSAMPLINGDELAY_1CYCLE;
    CHECK(HAL_ADCEx_MultiModeConfigChannel(&hadc1, &mm));

    hadc2.Instance = ADC2;                                /* slave: trigger comes from the master */
    adc_common_fill(&hadc2);
    hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    CHECK(HAL_ADC_Init(&hadc2));

    adc_channels(s_adc_smp[0]);
    __HAL_LINKDMA(&hadc1, DMA_Handle, hdma_adc1);

    CHECK(HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED));
    CHECK(HAL_ADCEx_Calibration_Start(&hadc2, ADC_SINGLE_ENDED));
}

/* First half of the set-up: everything the LCD needs. main() brings the LCD up
 * right after this, so that a failure in board_init() can be shown on it. */
void board_init_pins(void)
{
    /* PB4 (MUX_S1) and PB6 (LCD_D4) are also UCPD1 CC pins with dead-battery
     * pull-downs enabled at reset; release them, as CubeMX does. */
    HAL_PWREx_DisableUCPDDeadBattery();

    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;      /* cycle counter for delay_us() */
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    gpio_init();
}

void board_init(void)
{
    uart_init();
    dma_init();
    tim6_init();
    tim1_init();
    dac_init();
    adc_init();
}

void board_set_freq(int freq_idx)
{
    __HAL_TIM_SET_AUTORELOAD(&htim6, s_tim6_arr[freq_idx]);
    __HAL_TIM_SET_COUNTER(&htim6, 0);
    adc_channels(s_adc_smp[freq_idx]);    /* only called while no acquisition is running */
}

void board_mux(int addr, int enable)
{
    HAL_GPIO_WritePin(MUX_INH_PORT, MUX_INH_PIN, GPIO_PIN_SET);   /* break before make */
    HAL_GPIO_WritePin(MUX_S0_PORT, MUX_S0_PIN, (addr & 1) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MUX_S1_PORT, MUX_S1_PIN, (addr & 2) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MUX_S2_PORT, MUX_S2_PIN, (addr & 4) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    if (enable) {
        HAL_GPIO_WritePin(MUX_INH_PORT, MUX_INH_PIN, GPIO_PIN_RESET);
    }
}

int board_button_down(void)
{
    return HAL_GPIO_ReadPin(BTN_PORT, BTN_PIN) == GPIO_PIN_RESET;
}
