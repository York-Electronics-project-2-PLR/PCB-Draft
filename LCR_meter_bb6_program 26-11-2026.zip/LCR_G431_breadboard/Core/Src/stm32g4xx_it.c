/*
 * stm32g4xx_it.c - interrupt handlers used by this firmware. Every other
 * vector falls through to Default_Handler in the startup file.
 */
#include "board.h"
#include "ui.h"

void SysTick_Handler(void)
{
    HAL_IncTick();
    ui_button_tick();
}

void DMA1_Channel1_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&hdma_adc1);        /* end of an ADC block -> HAL_ADC_ConvCpltCallback */
}

void USART2_IRQHandler(void)
{
    HAL_UART_IRQHandler(&huart2);          /* console receive -> HAL_UART_RxCpltCallback */
}

void HardFault_Handler(void)
{
    board_error("HardFault");
}
