/*
 * phase_cmp.c - signed phase from the two comparator outputs.
 *
 * TIM1 counts at 32 MHz (16 bit, wraps every 2.05 ms). CH1 captures rising
 * edges of PHASE_S (VS > VMID), CH2 those of PHASE_X (VX > VMID). Because
 * one period (<= 32000 counts at 1 kHz) is shorter than the wrap, all
 * differences can be taken modulo 2^16. Each CH2 edge is paired with the
 * latest CH1 edge before it; results are averaged as unit vectors so the
 * +-180 degree boundary does not cause jumps.
 */
#include "phase_cmp.h"
#include "board.h"
#include <math.h>

float phase_cmp_measure_deg(int periods, uint32_t timeout_ms)
{
    TIM_TypeDef *t = htim1.Instance;
    uint16_t last_s = 0, prev_s = 0;
    int have_s = 0, n_period = 0, n_pair = 0;
    uint32_t sum_period = 0;
    uint16_t pend_x[4];
    int n_pend = 0;
    float sum_c = 0.0f, sum_s = 0.0f;

    (void)t->CCR1;                                  /* reading clears stale capture flags */
    (void)t->CCR2;
    t->SR = ~(TIM_SR_CC1OF | TIM_SR_CC2OF);

    uint32_t t0 = HAL_GetTick();
    while (n_pair < periods && HAL_GetTick() - t0 < timeout_ms) {
        uint32_t sr = t->SR;
        if (sr & TIM_SR_CC1IF) {
            prev_s = last_s;
            last_s = (uint16_t)t->CCR1;
            if (have_s) {
                sum_period += (uint16_t)(last_s - prev_s);
                n_period++;
            }
            have_s++;
        }
        if (sr & TIM_SR_CC2IF) {
            /* keep X edges only once the period is known: older ones could be more than
             * one 16-bit wrap away from the S edge they would be paired with */
            if (n_period > 0 && n_pend < 4) {
                pend_x[n_pend++] = (uint16_t)t->CCR2;
            } else {
                (void)t->CCR2;
            }
        }
        /* pair X edges once the period is known */
        if (n_period > 0 && n_pend > 0 && have_s >= 2) {
            float T = (float)sum_period / (float)n_period;
            for (int i = 0; i < n_pend; i++) {
                uint16_t d = (uint16_t)(pend_x[i] - last_s);  /* X after the latest S edge */
                if ((float)d >= T) {
                    d = (uint16_t)(pend_x[i] - prev_s);       /* X arrived before that S edge */
                }
                if ((float)d < T) {
                    float phi = -2.0f * (float)M_PI * (float)d / T;   /* tS - tX = -d */
                    sum_c += cosf(phi);
                    sum_s += sinf(phi);
                    n_pair++;
                }
            }
            n_pend = 0;
        }
    }
    if (n_pair == 0) {
        return NAN;
    }
    return atan2f(sum_s, sum_c) * (180.0f / (float)M_PI);
}
