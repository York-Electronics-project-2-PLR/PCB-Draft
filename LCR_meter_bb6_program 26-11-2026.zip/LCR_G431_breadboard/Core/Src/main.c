/*
 * LCR meter RevC firmware - NUCLEO-G431KB + carrier board (2x OPA388, 2x CD74HC4051, TLV3202, LCD1602).
 *
 * Loop: read console / button -> measure (auto range) -> LCD -> one CSV line on the virtual COM port.
 * Hardware reference: STM32G431_LCR_Handoff_RevC/eda_output (schematic P1-P3, GPIO map) and project_spec.md section 08.
 */
#include "board.h"
#include "calib.h"
#include "lcd1602.h"
#include "lcr.h"
#include "phase_cmp.h"
#include "ui.h"

int main(void)
{
    HAL_Init();
    board_clock_init();
    board_init_pins();
    lcd_init();                      /* LCD first: from here on a start-up failure is shown on it */
    lcd_line(0, FW_NAME);
    lcd_line(1, "starting...");
    board_init();
    cal_init();
    lcr_init();
    ui_splash();
    console_init();

    ui_state_t st = { .forced_range = -1, .stream = 1, .cmp_phase = 0 };
    lcr_result_t r;

    for (;;) {
        console_poll(&st);

        btn_event_t ev = ui_button();
        if (ev == BTN_SHORT) {
            lcr_set_freq((lcr_get_freq() + 1) % NUM_FREQS);
        } else if (ev == BTN_LONG) {
            ui_cal_wizard();
        }

        lcr_measure(&r, st.forced_range);
        if (st.cmp_phase && r.status == ST_OK) {
            r.phase_cmp_deg = phase_cmp_measure_deg(16, 60);
        }
        ui_show(&r);
        if (st.stream) {
            console_report(&r);
        }
    }
}
