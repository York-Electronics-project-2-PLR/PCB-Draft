/*
 * lcd1602.c - HD44780 driver, 4-bit mode.
 *
 * RW is tied to GND on the board, so the busy flag cannot be read: every
 * command is followed by a fixed delay longer than the datasheet maximum.
 * The 5 V module accepts the 3.3 V outputs (HD44780 VIH = 2.2 V at VCC = 5 V)
 * and never drives the data lines, so no 5 V reaches the STM32.
 */
#include "lcd1602.h"
#include "board.h"

static const uint8_t s_glyphs[3][8] = {
    { 0x0E, 0x11, 0x11, 0x11, 0x0A, 0x1B, 0x00, 0x00 },   /* 1: ohm */
    { 0x00, 0x11, 0x11, 0x11, 0x13, 0x1D, 0x10, 0x10 },   /* 2: micro */
    { 0x0C, 0x12, 0x12, 0x0C, 0x00, 0x00, 0x00, 0x00 },   /* 3: degree */
};

static int s_ready;

static void put_nibble(uint8_t n)
{
    HAL_GPIO_WritePin(LCD_D4_PORT, LCD_D4_PIN, (n & 1) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D5_PORT, LCD_D5_PIN, (n & 2) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D6_PORT, LCD_D6_PIN, (n & 4) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_D7_PORT, LCD_D7_PIN, (n & 8) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    delay_us(1);
    HAL_GPIO_WritePin(LCD_E_PORT, LCD_E_PIN, GPIO_PIN_SET);     /* E pulse >= 450 ns */
    delay_us(1);
    HAL_GPIO_WritePin(LCD_E_PORT, LCD_E_PIN, GPIO_PIN_RESET);
    delay_us(1);
}

static void send(uint8_t b, int is_data)
{
    HAL_GPIO_WritePin(LCD_RS_PORT, LCD_RS_PIN, is_data ? GPIO_PIN_SET : GPIO_PIN_RESET);
    put_nibble(b >> 4);
    put_nibble(b & 0x0F);
    delay_us(50);                                                /* 37 us max per instruction */
}

static void cmd(uint8_t c)
{
    send(c, 0);
    if (c == 0x01 || c == 0x02) {
        HAL_Delay(2);                                            /* clear / home: 1.52 ms */
    }
}

void lcd_init(void)
{
    HAL_Delay(50);                                               /* > 40 ms after VDD reaches 4.5 V */
    HAL_GPIO_WritePin(LCD_RS_PORT, LCD_RS_PIN, GPIO_PIN_RESET);
    put_nibble(0x3);                                             /* datasheet 4-bit initialisation by instruction */
    HAL_Delay(5);
    put_nibble(0x3);
    delay_us(200);
    put_nibble(0x3);
    delay_us(200);
    put_nibble(0x2);                                             /* now in 4-bit mode */
    delay_us(200);
    cmd(0x28);                                                   /* 2 lines, 5x8 font */
    cmd(0x08);                                                   /* display off */
    cmd(0x01);                                                   /* clear */
    cmd(0x06);                                                   /* entry mode: increment, no shift */
    for (int g = 0; g < 3; g++) {
        cmd((uint8_t)(0x40 | ((g + 1) << 3)));                   /* CGRAM address of character g+1 */
        for (int r = 0; r < 8; r++) {
            send(s_glyphs[g][r], 1);
        }
    }
    cmd(0x0C);                                                   /* display on, cursor off */
    s_ready = 1;
}

int lcd_ready(void)
{
    return s_ready;
}

void lcd_clear(void)
{
    cmd(0x01);
}

void lcd_line(int row, const char *text)
{
    cmd(row ? 0xC0 : 0x80);
    int i = 0;
    for (; i < 16 && text[i] != '\0'; i++) {
        send((uint8_t)text[i], 1);
    }
    for (; i < 16; i++) {
        send(' ', 1);
    }
}
