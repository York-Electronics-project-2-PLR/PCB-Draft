/*
 * calib.c - calibration data and its flash storage.
 *
 * Open/short compensation (standard LCR-meter model: series residual Zs,
 * parallel stray Zo, both measured through the same path as the DUT):
 *
 *        Z = (Zm - Zs)(Zo - Zs) / (Zo - Zm)
 *
 * An open reading that is too large to measure on a range (typical on the
 * low ranges) is stored as "not valid" and treated as infinite, which turns
 * the formula into Z = Zm - Zs. A short reading that is too small (high
 * ranges) is treated as zero.
 */
#include "calib.h"
#include "stm32g4xx_hal.h"
#include <math.h>
#include <stddef.h>
#include <string.h>

#define CAL_MAGIC    0x4C435231u   /* "LCR1" */
#define CAL_VERSION  1u

typedef struct {
    float zo_re, zo_im, zs_re, zs_im;
    uint32_t flags;
} cal_entry_t;

typedef struct {
    uint32_t magic;
    uint32_t version;
    float rref[NUM_RANGES];
    cal_entry_t e[NUM_FREQS][NUM_RANGES];
    uint32_t crc;
} cal_store_t;                       /* 232 bytes = 29 double-words */

_Static_assert(sizeof(cal_store_t) % 8 == 0, "flash image must be whole double-words");
_Static_assert(sizeof(cal_store_t) <= 2048, "must fit one flash page");

static cal_store_t s_cal;
static int s_from_flash;

static uint32_t fnv1a(const void *p, uint32_t n)
{
    const uint8_t *b = p;
    uint32_t h = 2166136261u;
    while (n--) {
        h = (h ^ *b++) * 16777619u;
    }
    return h;
}

static uint32_t crc_of(const cal_store_t *c)
{
    return fnv1a(c, (uint32_t)offsetof(cal_store_t, crc));
}

static void defaults(void)
{
    static const float nominal[NUM_RANGES] = RREF_NOMINAL;
    memset(&s_cal, 0, sizeof s_cal);
    s_cal.magic = CAL_MAGIC;
    s_cal.version = CAL_VERSION;
    memcpy(s_cal.rref, nominal, sizeof nominal);
}

void cal_init(void)
{
    const cal_store_t *f = (const cal_store_t *)CAL_FLASH_ADDR;
    if (f->magic == CAL_MAGIC && f->version == CAL_VERSION && f->crc == crc_of(f)) {
        memcpy(&s_cal, f, sizeof s_cal);
        s_from_flash = 1;
    } else {
        defaults();
        s_from_flash = 0;
    }
}

int cal_loaded_from_flash(void)
{
    return s_from_flash;
}

int cal_save(void)
{
    FLASH_EraseInitTypeDef er = {0};
    uint32_t page_err = 0;
    int rc = 0;

    s_cal.crc = crc_of(&s_cal);
    HAL_FLASH_Unlock();
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_ALL_ERRORS);
    er.TypeErase = FLASH_TYPEERASE_PAGES;
    er.Banks = FLASH_BANK_1;
    er.Page = CAL_FLASH_PAGE;
    er.NbPages = 1;
    if (HAL_FLASHEx_Erase(&er, &page_err) != HAL_OK) {
        rc = -1;
    } else {
        const uint64_t *src = (const uint64_t *)(const void *)&s_cal;
        for (uint32_t i = 0; i < sizeof s_cal / 8; i++) {
            if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, CAL_FLASH_ADDR + 8u * i, src[i]) != HAL_OK) {
                rc = -2;
                break;
            }
        }
    }
    HAL_FLASH_Lock();
    if (rc == 0 && memcmp((const void *)CAL_FLASH_ADDR, &s_cal, sizeof s_cal) != 0) {
        rc = -3;
    }
    if (rc == 0) {
        s_from_flash = 1;
    }
    return rc;
}

float cal_rref(int range)
{
    return s_cal.rref[range];
}

void cal_set_rref(int range, float ohm)
{
    s_cal.rref[range] = ohm;
}

void cal_set_open(int freq, int range, float complex z, int valid)
{
    cal_entry_t *e = &s_cal.e[freq][range];
    e->zo_re = crealf(z);
    e->zo_im = cimagf(z);
    e->flags = valid ? (e->flags | 1u) : (e->flags & ~1u);
}

void cal_set_short(int freq, int range, float complex z, int valid)
{
    cal_entry_t *e = &s_cal.e[freq][range];
    e->zs_re = crealf(z);
    e->zs_im = cimagf(z);
    e->flags = valid ? (e->flags | 2u) : (e->flags & ~2u);
}

void cal_clear(int freq)
{
    memset(s_cal.e[freq], 0, sizeof s_cal.e[freq]);
}

int cal_flags(int freq, int range)
{
    return (int)s_cal.e[freq][range].flags;
}

float complex cal_apply(int freq, int range, float complex zm, int *applied)
{
    const cal_entry_t *e = &s_cal.e[freq][range];
    float complex zs = (e->flags & 2u) ? (e->zs_re + I * e->zs_im) : 0.0f;
    *applied = (e->flags & 3u) != 0;
    if (e->flags & 1u) {
        float complex zo = e->zo_re + I * e->zo_im;
        float complex den = zo - zm;
        if (cabsf(den) > 1e-6f * cabsf(zo)) {
            return (zm - zs) * (zo - zs) / den;
        }
        /* reading equals the open reading: effectively nothing connected */
        return INFINITY;
    }
    return zm - zs;
}
