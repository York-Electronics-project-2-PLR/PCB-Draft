/*
 * lcr.c - the measurement itself (spec section 08, amplitude AND phase taken
 * from the two ADC channels; the comparators are an independent cross-check,
 * see phase_cmp.c).
 *
 *   DAC -> U1 filter -> R5 -> U3 (selected Rref) -> VX -> DUT -> VMID
 *                             VS = node before Rref (read through U4)
 *
 *   Fundamental phasors (single-bin DFT over whole periods, DC/VMID drops out):
 *       S = sum vs[n] e^{-j 2 pi n / N},   X = sum vx[n] e^{-j 2 pi n / N}
 *   Current through Rref = (VS - VX) / Rref, voltage across DUT = VX, so
 *       H = X / S,    Z = Rref * H / (1 - H)
 */
#include "lcr.h"
#include "board.h"
#include "calib.h"
#include <math.h>

const char *const g_range_name[NUM_RANGES] = RANGE_NAME;

static const float    s_freq_hz[NUM_FREQS] = FREQ_HZ_LIST;
static const int      s_reps[NUM_FREQS] = FREQ_REPS;
static const uint8_t  s_addr[NUM_RANGES] = RANGE_ADDR;
static const uint16_t s_settle_ms[NUM_RANGES] = RANGE_SETTLE_MS;

static uint32_t s_wave[WAVE_N];              /* 32-bit entries: the DAC DMA channel must use word access (see board.c) */
static uint32_t s_buf[ACQ_SAMPLES];          /* low half = ADC1 (VS), high half = ADC2 (VX) */
static float    s_cos[WAVE_N], s_sin[WAVE_N];
static volatile int s_acq_done;
static int s_freq;
static int s_range = -1;
static int s_auto_range = START_RANGE;

_Static_assert((WAVE_N & (WAVE_N - 1)) == 0, "WAVE_N must be a power of two");

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance == ADC1) {
        s_acq_done = 1;
    }
}

void lcr_init(void)
{
    for (int k = 0; k < WAVE_N; k++) {
        float a = 2.0f * (float)M_PI * (float)k / (float)WAVE_N;
        s_cos[k] = cosf(a);
        s_sin[k] = sinf(a);
        s_wave[k] = (uint32_t)lroundf((float)DAC_MID + (float)DAC_AMPL * s_sin[k]);
    }
    s_freq = 0;
    board_set_freq(s_freq);
    if (HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_1, s_wave, WAVE_N, DAC_ALIGN_12B_R) != HAL_OK) {
        board_error("DAC start");
    }
    if (HAL_TIM_Base_Start(&htim6) != HAL_OK) {
        board_error("TIM6 start");
    }
    HAL_Delay(20);                            /* let the filter and VMID settle */
}

void lcr_set_freq(int freq)
{
    if (freq == s_freq) {
        return;
    }
    s_freq = freq;
    board_set_freq(freq);
    HAL_Delay(20);
}

int lcr_get_freq(void)
{
    return s_freq;
}

float lcr_freq_hz(int freq)
{
    return s_freq_hz[freq];
}

static void select_range(int range)
{
    if (range == s_range) {
        return;
    }
    board_mux(s_addr[range], 1);
    s_range = range;
    HAL_Delay(s_settle_ms[range]);
}

/* One DMA block. ph[] receives its two fundamental phasors in ADC codes (peak):
 * ph[0] + j ph[1] = VS, ph[2] + j ph[3] = VX. Returns 0 on success. */
static int acquire(float ph[4], uint16_t lim[4])
{
    s_acq_done = 0;
    if (HAL_ADCEx_MultiModeStart_DMA(&hadc1, s_buf, ACQ_SAMPLES) != HAL_OK) {
        return -1;
    }
    uint32_t t0 = HAL_GetTick();
    while (!s_acq_done) {
        if (HAL_GetTick() - t0 > 200u) {
            HAL_ADCEx_MultiModeStop_DMA(&hadc1);
            return -1;
        }
    }
    HAL_ADCEx_MultiModeStop_DMA(&hadc1);

    float sr = 0, si = 0, xr = 0, xi = 0;
    for (int i = 0; i < ACQ_SAMPLES; i++) {
        uint32_t w = s_buf[i];
        uint16_t a = (uint16_t)(w & 0xFFFFu), b = (uint16_t)(w >> 16);
        int k = i & (WAVE_N - 1);
        float c = s_cos[k], s = s_sin[k];
        sr += (float)a * c;
        si -= (float)a * s;
        xr += (float)b * c;
        xi -= (float)b * s;
        if (a < lim[0]) lim[0] = a;
        if (a > lim[1]) lim[1] = a;
        if (b < lim[2]) lim[2] = b;
        if (b > lim[3]) lim[3] = b;
    }
    const float k = 2.0f / (float)ACQ_SAMPLES;
    ph[0] = sr * k;
    ph[1] = si * k;
    ph[2] = xr * k;
    ph[3] = xi * k;
    return 0;
}

void lcr_measure_range(int range, lcr_result_t *r)
{
    float pss = 0.0f, pxx = 0.0f;                  /* sum of |S|^2 and |X|^2 over the blocks */
    float complex pxs = 0.0f;                      /* sum of X conj(S) */
    uint16_t lim[4] = { 0xFFFF, 0, 0xFFFF, 0 };    /* vs min, vs max, vx min, vx max */
    int reps = s_reps[s_freq];

    select_range(range);
    r->freq = s_freq;
    r->f_hz = s_freq_hz[s_freq];
    r->range = range;
    r->rref = cal_rref(range);
    r->kind = '?';
    r->value = r->esr = r->phase_deg = 0.0f;
    r->phase_cmp_deg = NAN;
    r->calibrated = 0;

    /* Every block starts at an arbitrary point of the sine table (the DAC free-runs),
     * so the phasors of different blocks are rotated against each other and must not
     * be added directly: they could cancel. |S|^2, |X|^2 and X conj(S) do not depend
     * on that rotation, so those are what is averaged. H = sum(X conj S) / sum(|S|^2). */
    for (int i = 0; i < reps; i++) {
        float ph[4];
        if (acquire(ph, lim) != 0) {
            r->status = ST_TIMEOUT;
            return;
        }
        float complex S = ph[0] + I * ph[1];
        float complex X = ph[2] + I * ph[3];
        pss += ph[0] * ph[0] + ph[1] * ph[1];
        pxx += ph[2] * ph[2] + ph[3] * ph[3];
        pxs += X * conjf(S);
    }

    const float code_to_volt = ADC_VREF_V / ADC_FULLSCALE;
    r->vs_pk = sqrtf(pss / (float)reps) * code_to_volt;
    r->vx_pk = sqrtf(pxx / (float)reps) * code_to_volt;
    int clipped = lim[0] < CLIP_LO || lim[1] > CLIP_HI || lim[2] < CLIP_LO || lim[3] > CLIP_HI;

    if (r->vs_pk < MIN_VS_PEAK_V) {
        r->H = 0;
        r->z_raw = r->z = 0;
        r->status = clipped ? ST_CLIP : ST_NOSIG;      /* an input stuck at a rail also shows no signal: say so */
        return;
    }
    r->H = pxs / pss;
    r->z_raw = r->rref * r->H / (1.0f - r->H);
    r->z = cal_apply(s_freq, range, r->z_raw, &r->calibrated);

    if (clipped) {
        r->status = ST_CLIP;
    } else if (cabsf(r->H) < H_EDGE) {
        r->status = ST_LOW;
    } else if (cabsf(1.0f - r->H) < H_EDGE) {
        r->status = ST_HIGH;
    } else {
        r->status = ST_OK;
    }
}

/* Diagnostics: one block of raw ADC codes. range < 0 keeps the range as it is. */
int lcr_diag_block(int range, lcr_diag_t *d)
{
    float ph[4];
    uint16_t lim[4] = { 0xFFFF, 0, 0xFFFF, 0 };
    uint32_t sa = 0, sb = 0;

    if (range >= 0) {
        select_range(range);
    }
    if (acquire(ph, lim) != 0) {
        return -1;
    }
    for (int i = 0; i < ACQ_SAMPLES; i++) {
        sa += s_buf[i] & 0xFFFFu;
        sb += s_buf[i] >> 16;
    }
    d->min[0] = lim[0];
    d->max[0] = lim[1];
    d->min[1] = lim[2];
    d->max[1] = lim[3];
    d->mean[0] = (float)sa / (float)ACQ_SAMPLES;
    d->mean[1] = (float)sb / (float)ACQ_SAMPLES;
    d->ampl[0] = sqrtf(ph[0] * ph[0] + ph[1] * ph[1]);
    d->ampl[1] = sqrtf(ph[2] * ph[2] + ph[3] * ph[3]);
    return 0;
}

/* Diagnostics: one block with the multiplexers on any 4051 address 0..7, also the three
 * that are not used. Shows on which channel a misplaced wire or resistor really sits. */
int lcr_diag_addr(int addr, lcr_diag_t *d)
{
    board_mux(addr, 1);
    s_range = -1;                            /* the next normal measurement selects its range again */
    HAL_Delay(150);
    return lcr_diag_block(-1, d);
}

/* Diagnostics: the second ADC looks at the DAC pin itself (PA4 = ADC2_IN17) instead of VX. */
int lcr_diag_dac_pin(lcr_diag_t *d)
{
    board_adc2_channel(ADC_CHANNEL_17);
    int rc = lcr_diag_block(-1, d);
    board_adc2_channel(ADC_CHANNEL_4);
    return rc;
}

/* "dead" is a bit mask of ranges that showed no drive signal during this measurement
 * (a fault limited to one range: its 4051 channel, a wire or the reference resistor).
 * Auto-ranging simply leaves those ranges out. */
static int range_up(int rg, unsigned dead)
{
    for (int k = rg + 1; k < NUM_RANGES; k++) {
        if (!((dead >> k) & 1u)) {
            return k;
        }
    }
    return NUM_RANGES;
}

static int range_down(int rg, unsigned dead)
{
    for (int k = rg - 1; k >= 0; k--) {
        if (!((dead >> k) & 1u)) {
            return k;
        }
    }
    return -1;
}

static int best_range(float mag, unsigned dead, int fallback)
{
    int best = fallback;
    float bd = INFINITY;
    for (int i = 0; i < NUM_RANGES; i++) {
        if ((dead >> i) & 1u) {
            continue;
        }
        float d = isfinite(mag) ? fabsf(log10f(mag / cal_rref(i))) : (float)(NUM_RANGES - i);   /* not finite: highest usable range */
        if (d < bd) {
            bd = d;
            best = i;
        }
    }
    return best;
}

static void classify(lcr_result_t *r)
{
    if (r->status != ST_OK) {
        return;
    }
    float mag = cabsf(r->z);
    if (!isfinite(mag) || mag > Z_OPEN_OHM) {
        r->status = ST_OPEN;
        return;
    }
    if (mag < Z_SHORT_OHM) {
        r->status = ST_SHORT;
        return;
    }
    float R = crealf(r->z), X = cimagf(r->z);
    float w = 2.0f * (float)M_PI * r->f_hz;
    r->phase_deg = cargf(r->z) * (180.0f / (float)M_PI);
    r->esr = R;
    if (fabsf(X) < REACTIVE_MIN * mag) {
        r->kind = 'R';
        r->value = R;
    } else if (X > 0.0f) {
        r->kind = 'L';
        r->value = X / w;
    } else {
        r->kind = 'C';
        r->value = -1.0f / (w * X);
    }
}

void lcr_measure(lcr_result_t *r, int forced_range)
{
    if (forced_range >= 0) {
        lcr_measure_range(forced_range, r);
        classify(r);
        return;
    }

    int rg = s_auto_range;
    unsigned dead = 0;
    for (int it = 0; it < 2 * NUM_RANGES + 2; it++) {
        lcr_measure_range(rg, r);
        int next = rg;
        if (r->status == ST_NOSIG) {
            /* No drive on this range. Before reporting NO SIGNAL try the other ranges: on the
             * real breadboard one range was open while the others worked, and the meter must
             * not get stuck on the broken one. */
            dead |= 1u << rg;
            next = range_down(rg, dead);
            if (next < 0) {
                next = range_up(rg, dead);
            }
            if (next >= NUM_RANGES) {
                break;                       /* no range has a signal: it really is NO SIGNAL */
            }
            rg = next;
            continue;
        }
        if (r->status == ST_HIGH) {
            next = range_up(rg, dead);
        } else if (r->status == ST_LOW) {
            next = range_down(rg, dead);
        } else if (r->status == ST_OK) {
            float mag = cabsf(r->z);
            int best = best_range(mag, dead, rg);
            if (best != rg) {
                float cur = isfinite(mag) ? fabsf(log10f(mag / cal_rref(rg))) : INFINITY;
                float bst = isfinite(mag) ? fabsf(log10f(mag / cal_rref(best))) : 0.0f;
                if (cur - bst > RANGE_HYST_DEC) {
                    next = best;
                }
            }
        } else {
            break;                           /* clipping / timeout: changing range won't help */
        }
        if (next < 0) {
            r->status = ST_SHORT;            /* still too small on the lowest range */
            break;
        }
        if (next >= NUM_RANGES) {
            r->status = ST_OPEN;             /* still too large on the highest range */
            break;
        }
        if (next == rg) {
            break;
        }
        rg = next;
    }
    s_auto_range = r->range;
    classify(r);
}

const char *lcr_status_text(lcr_status_t s)
{
    switch (s) {
    case ST_OK:      return "OK";
    case ST_NOSIG:   return "NO_SIGNAL";
    case ST_CLIP:    return "CLIP";
    case ST_HIGH:    return "TOO_HIGH";
    case ST_LOW:     return "TOO_LOW";
    case ST_OPEN:    return "OPEN";
    case ST_SHORT:   return "SHORT";
    case ST_TIMEOUT: return "TIMEOUT";
    }
    return "?";
}
