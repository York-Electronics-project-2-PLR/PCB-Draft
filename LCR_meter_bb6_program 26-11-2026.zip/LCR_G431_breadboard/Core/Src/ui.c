/*
 * ui.c - what the user sees and touches.
 *
 * LCD (16x2):
 *   C 10.03nF  1kHz      kind, '*' instead of the space = no calibration on this range
 *   ESR 1.234Ω   10k     ESR (L/C) or phase (R), and the reference range in use
 *
 * Button: short press = change test frequency (1 kHz <-> 10 kHz)
 *         hold 1.5 s  = open/short calibration wizard for the current frequency
 *
 * Serial console (ST-LINK virtual COM port, 115200 8N1): type "help".
 */
#include "ui.h"
#include "board.h"
#include "calib.h"
#include "lcd1602.h"
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------ formatting */

/* engineering notation, 4 significant digits: 10.03n, 4.702k, 999.9m */
static void eng(char *buf, size_t n, float v, const char *unit, int lcd)
{
    static const char *const pfx_lcd[] = { "p", "n", LCD_MU, "m", "", "k", "M", "G" };
    static const char *const pfx_txt[] = { "p", "n", "u", "m", "", "k", "M", "G" };
    if (!isfinite(v)) {
        snprintf(buf, n, "---");
        return;
    }
    int e = 4;
    float a = fabsf(v);
    if (a > 0.0f) {
        while (a >= 999.95f && e < 7) {
            a /= 1000.0f;
            v /= 1000.0f;
            e++;
        }
        while (a < 0.99995f && e > 0) {
            a *= 1000.0f;
            v *= 1000.0f;
            e--;
        }
    }
    const char *fmt = (a >= 99.995f) ? "%.1f%s%s" : (a >= 9.9995f) ? "%.2f%s%s" : "%.3f%s%s";
    snprintf(buf, n, fmt, (double)v, (lcd ? pfx_lcd : pfx_txt)[e], unit);
}

static const char *freq_tag(const lcr_result_t *r)
{
    return r->f_hz >= 9999.0f ? "10kHz" : "1kHz";
}

/* ------------------------------------------------------------------ LCD */

void ui_splash(void)
{
    lcd_line(0, FW_NAME);
    lcd_line(1, cal_loaded_from_flash() ? "cal: from flash" : "cal: none yet");
    HAL_Delay(1500);
}

/* left text, right text flush right; the left part is cut if both do not fit in 16 */
static void cols(char *out, size_t n, const char *left, const char *right)
{
    int w = 16 - (int)strlen(right);
    snprintf(out, n, "%-*.*s%s", w, w, left, right);
}

void ui_show(const lcr_result_t *r)
{
    char l1[40], l2[40], v[24], e[24], left[32], rn[8];
    snprintf(rn, sizeof rn, " %s", g_range_name[r->range]);

    switch (r->status) {
    case ST_OK:
        if (r->kind == 'R') {
            eng(v, sizeof v, r->value, LCD_OHM, 1);
            snprintf(left, sizeof left, "ph %+.1f" LCD_DEG, (double)r->phase_deg);
        } else {
            eng(v, sizeof v, r->value, r->kind == 'L' ? "H" : "F", 1);
            eng(e, sizeof e, r->esr, LCD_OHM, 1);
            snprintf(left, sizeof left, "ESR %s", e);
        }
        cols(l2, sizeof l2, left, rn);
        snprintf(left, sizeof left, "%c%c%s", r->kind, r->calibrated ? ' ' : '*', v);
        snprintf(e, sizeof e, " %s", freq_tag(r));
        cols(l1, sizeof l1, left, e);
        break;
    case ST_OPEN:
        snprintf(l1, sizeof l1, "OPEN (no part)");
        cols(l2, sizeof l2, "", rn);
        break;
    case ST_SHORT:
        snprintf(l1, sizeof l1, "SHORT");
        cols(l2, sizeof l2, "", rn);
        break;
    case ST_HIGH:
    case ST_LOW:
        snprintf(l1, sizeof l1, "OUT OF RANGE");
        snprintf(l2, sizeof l2, "%s on%s", r->status == ST_HIGH ? "too big" : "too small", rn);
        break;
    case ST_NOSIG:
        snprintf(l1, sizeof l1, "NO SIGNAL");
        snprintf(l2, sizeof l2, "check DAC/U1/R5");
        break;
    case ST_CLIP:
        snprintf(l1, sizeof l1, "ADC CLIPPING");
        snprintf(l2, sizeof l2, "check VMID/wires");
        break;
    default:
        snprintf(l1, sizeof l1, "ADC TIMEOUT");
        snprintf(l2, sizeof l2, "restart board");
        break;
    }
    lcd_line(0, l1);
    lcd_line(1, l2);
}

/* --------------------------------------------------------------- button */

static volatile btn_event_t s_btn_evt = BTN_NONE;

void ui_button_tick(void)
{
    static uint8_t integ;           /* 10 ms integrating debounce */
    static uint8_t pressed;
    static uint32_t held;

    if (board_button_down()) {
        if (integ < 10) integ++;
    } else if (integ > 0) {
        integ--;
    }
    if (!pressed) {
        if (integ == 10) {
            pressed = 1;
            held = 0;
        }
    } else {
        held++;
        if (held == BTN_LONG_MS) {
            s_btn_evt = BTN_LONG;
        }
        if (integ == 0) {
            pressed = 0;
            if (held < BTN_LONG_MS) {
                s_btn_evt = BTN_SHORT;
            }
        }
    }
}

btn_event_t ui_button(void)
{
    btn_event_t e = s_btn_evt;
    s_btn_evt = BTN_NONE;
    return e;
}

/* ---------------------------------------------------------- calibration */

/* Records the raw reading of every range. kind 'o' = open (no part), 's' = short.
 * Returns 0, or -1 if the excitation is not working. */
static int record_cal(char kind)
{
    int f = lcr_get_freq();
    lcr_result_t r;
    for (int rg = 0; rg < NUM_RANGES; rg++) {
        lcr_measure_range(rg, &r);
        if (r.status == ST_NOSIG || r.status == ST_CLIP || r.status == ST_TIMEOUT) {
            console_printf("cal %c: range %s failed (%s)\r\n", kind, g_range_name[rg], lcr_status_text(r.status));
            return -1;
        }
        int valid;
        if (kind == 'o') {
            valid = cabsf(1.0f - r.H) > H_EDGE_CAL;   /* otherwise: open is "infinite" on this range */
            cal_set_open(f, rg, r.z_raw, valid);
        } else {
            valid = cabsf(r.H) > H_EDGE_CAL;          /* otherwise: short is "zero" on this range */
            cal_set_short(f, rg, r.z_raw, valid);
        }
        console_printf("cal %c f=%.0f %s: Zraw=%.6g%+.6gj %s\r\n", kind, (double)r.f_hz, g_range_name[rg],
                       (double)crealf(r.z_raw), (double)cimagf(r.z_raw), valid ? "stored" : "out of reach (ignored)");
    }
    return 0;
}

static int wait_button(void)
{
    (void)ui_button();
    for (;;) {
        btn_event_t e = ui_button();
        if (e == BTN_SHORT) return 1;
        if (e == BTN_LONG) return 0;
        HAL_Delay(5);
    }
}

void ui_cal_wizard(void)
{
    char l2[24];
    snprintf(l2, sizeof l2, "f=%s  BTN=go", lcr_get_freq() ? "10kHz" : "1kHz");

    lcd_line(0, "OPEN CAL:no part");
    lcd_line(1, l2);
    if (!wait_button()) goto cancel;
    lcd_line(0, "measuring open..");
    if (record_cal('o') != 0) goto fail;

    lcd_line(0, "SHORT CAL: join");
    lcd_line(1, "clips, BTN=go");
    if (!wait_button()) goto cancel;
    lcd_line(0, "measuring short.");
    if (record_cal('s') != 0) goto fail;

    lcd_line(0, cal_save() == 0 ? "CAL SAVED" : "SAVE FAILED");
    lcd_line(1, l2);
    HAL_Delay(1500);
    return;
fail:
    lcd_line(0, "CAL FAILED");
    lcd_line(1, "no signal?");
    HAL_Delay(2000);
    return;
cancel:
    lcd_line(0, "cal cancelled");
    lcd_line(1, "");
    HAL_Delay(1000);
}

/* -------------------------------------------------------------- console */

static uint8_t s_rx_byte;
static volatile uint8_t s_ring[64];
static volatile uint8_t s_head, s_tail;
static char s_line[40];
static uint8_t s_len;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *h)
{
    if (h->Instance == USART2) {
        uint8_t next = (uint8_t)((s_head + 1u) % sizeof s_ring);
        if (next != s_tail) {
            s_ring[s_head] = s_rx_byte;
            s_head = next;
        }
        HAL_UART_Receive_IT(&huart2, &s_rx_byte, 1);
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *h)
{
    if (h->Instance == USART2) {
        HAL_UART_Receive_IT(&huart2, &s_rx_byte, 1);   /* re-arm after noise / overrun */
    }
}

void console_printf(const char *fmt, ...)
{
    char buf[200];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    if (n > 0) {
        if (n >= (int)sizeof buf) n = sizeof buf - 1;
        HAL_UART_Transmit(&huart2, (uint8_t *)buf, (uint16_t)n, 100);
    }
}

static void print_help(void)
{
    console_printf(
        "\r\n" FW_NAME " - commands (end with Enter):\r\n"
        "  f         toggle 1 kHz / 10 kHz\r\n"
        "  a         auto range       0..4  fix range 100R/1k/10k/47k/1M\r\n"
        "  open      record open calibration (nothing on the clips)\r\n"
        "  short     record short calibration (clips joined)\r\n"
        "  r<i>=<v>  set measured reference resistor, e.g. r2=9987.4\r\n"
        "  save      write Rref + calibration to flash   clear  forget cal at this frequency\r\n"
        "  stream    CSV output on/off    cmp  comparator phase on/off    info  settings\r\n"
        "  raw       fault finding: raw ADC codes on every range and on the DAC pin\r\n"
        "  scan      fault finding: all eight 4051 addresses, also the unused ones\r\n");
}

static void print_header(void)
{
    console_printf("f_Hz,range,Rref,Vs_pk,Vx_pk,H_re,H_im,Zraw_re,Zraw_im,Z_re,Z_im,cal,status,kind,value,ESR,phase_deg,phase_cmp_deg\r\n");
}

static void print_info(void)
{
    console_printf("calibration %s\r\n", cal_loaded_from_flash() ? "loaded from flash" : "NOT in flash (defaults)");
    for (int r = 0; r < NUM_RANGES; r++) {
        console_printf("  range %d %-4s Rref=%.6g ohm  cal1k:%s%s cal10k:%s%s\r\n", r, g_range_name[r], (double)cal_rref(r),
                       (cal_flags(0, r) & 1) ? "O" : "-", (cal_flags(0, r) & 2) ? "S" : "-",
                       (cal_flags(1, r) & 1) ? "O" : "-", (cal_flags(1, r) & 2) ? "S" : "-");
    }
}

/* Fault finding: raw ADC codes on every range, then the DAC pin itself.
 * A healthy board shows a mean near 2048 (1.65 V) everywhere and, with nothing in the
 * clips, about the same amplitude on VS and VX; the DAC pin shows about DAC_AMPL codes. */
static void print_raw(void)
{
    lcr_diag_t d;
    console_printf("raw ADC codes (0..4095, 2048 = 1.65 V), f = %.0f Hz\r\n", (double)lcr_freq_hz(lcr_get_freq()));
    for (int rg = 0; rg < NUM_RANGES; rg++) {
        if (lcr_diag_block(rg, &d) != 0) {
            console_printf("  range %-4s ADC timeout\r\n", g_range_name[rg]);
            continue;
        }
        console_printf("  range %-4s VS min/mean/max %4u/%6.1f/%4u ampl %6.1f | VX min/mean/max %4u/%6.1f/%4u ampl %6.1f\r\n",
                       g_range_name[rg], d.min[0], (double)d.mean[0], d.max[0], (double)d.ampl[0],
                       d.min[1], (double)d.mean[1], d.max[1], (double)d.ampl[1]);
    }
    if (lcr_diag_dac_pin(&d) == 0) {
        console_printf("  DAC pin PA4 (expect mean 2048, ampl %d): min/mean/max %4u/%6.1f/%4u ampl %6.1f\r\n",
                       DAC_AMPL, d.min[1], (double)d.mean[1], d.max[1], (double)d.ampl[1]);
    } else {
        console_printf("  DAC pin: ADC timeout\r\n");
    }
    /* the registers that decide whether the DAC is fed: DAC, its DMA channel, the request router, the timer */
    console_printf("  DAC  CR=%08lX MCR=%08lX SR=%08lX DHR12R1=%03lX DOR1=%03lX | hal state=%u err=%lu\r\n",
                   (unsigned long)DAC1->CR, (unsigned long)DAC1->MCR, (unsigned long)DAC1->SR,
                   (unsigned long)DAC1->DHR12R1, (unsigned long)DAC1->DOR1, (unsigned)hdac1.State, (unsigned long)hdac1.ErrorCode);
    console_printf("  DMA1 ch2 CCR=%08lX CNDTR=%lu CPAR=%08lX CMAR=%08lX ISR=%08lX | mux1 CCR=%08lX | hal state=%u err=%lu\r\n",
                   (unsigned long)DMA1_Channel2->CCR, (unsigned long)DMA1_Channel2->CNDTR, (unsigned long)DMA1_Channel2->CPAR,
                   (unsigned long)DMA1_Channel2->CMAR, (unsigned long)DMA1->ISR, (unsigned long)DMAMUX1_Channel1->CCR,
                   (unsigned)hdma_dac1.State, (unsigned long)hdma_dac1.ErrorCode);
    console_printf("  TIM6 CR1=%04lX CR2=%04lX ARR=%lu CNT=%lu | RCC AHB1ENR=%08lX AHB2ENR=%08lX APB1ENR1=%08lX\r\n",
                   (unsigned long)TIM6->CR1, (unsigned long)TIM6->CR2, (unsigned long)TIM6->ARR, (unsigned long)TIM6->CNT,
                   (unsigned long)RCC->AHB1ENR, (unsigned long)RCC->AHB2ENR, (unsigned long)RCC->APB1ENR1);
}

/* Fault finding: every 4051 address, also the unused ones (5, 6, 7). With nothing in the
 * clips a correctly wired channel shows the full amplitude on VS and VX; an unused channel
 * shows a floating input (small amplitude, mean drifting away from 2048). */
static void print_scan(void)
{
    static const char *const use[8] = { "1k", "10k", "47k", "100R", "1M", "unused", "unused", "unused" };
    static const uint8_t pin[8] = { 13, 14, 15, 12, 1, 5, 2, 4 };
    lcr_diag_t d;
    console_printf("scan of all 4051 addresses (S2 S1 S0), f = %.0f Hz\r\n", (double)lcr_freq_hz(lcr_get_freq()));
    for (int a = 0; a < 8; a++) {
        if (lcr_diag_addr(a, &d) != 0) {
            console_printf("  addr %d: ADC timeout\r\n", a);
            continue;
        }
        console_printf("  addr %d%d%d ch%d pin%-2u %-6s VS mean %6.1f ampl %6.1f | VX mean %6.1f ampl %6.1f\r\n",
                       (a >> 2) & 1, (a >> 1) & 1, a & 1, a, pin[a], use[a],
                       (double)d.mean[0], (double)d.ampl[0], (double)d.mean[1], (double)d.ampl[1]);
    }
}

static void run_command(char *c, ui_state_t *st)
{
    if (!strcmp(c, "help") || !strcmp(c, "h") || !strcmp(c, "?")) {
        print_help();
    } else if (!strcmp(c, "raw")) {
        print_raw();
    } else if (!strcmp(c, "scan")) {
        print_scan();
    } else if (!strcmp(c, "f")) {
        lcr_set_freq((lcr_get_freq() + 1) % NUM_FREQS);
        console_printf("f = %.0f Hz\r\n", (double)lcr_freq_hz(lcr_get_freq()));
    } else if (!strcmp(c, "a")) {
        st->forced_range = -1;
        console_printf("auto range\r\n");
    } else if (c[0] >= '0' && c[0] < '0' + NUM_RANGES && c[1] == '\0') {
        st->forced_range = c[0] - '0';
        console_printf("range fixed to %s\r\n", g_range_name[st->forced_range]);
    } else if (!strcmp(c, "open")) {
        record_cal('o');
        console_printf("type save to keep it\r\n");
    } else if (!strcmp(c, "short")) {
        record_cal('s');
        console_printf("type save to keep it\r\n");
    } else if (c[0] == 'r' && c[1] >= '0' && c[1] < '0' + NUM_RANGES && c[2] == '=') {
        char *end;
        float v = strtof(c + 3, &end);
        if (end != c + 3 && v > 0.0f) {
            cal_set_rref(c[1] - '0', v);
            console_printf("Rref[%s] = %.6g ohm (type save to keep it)\r\n", g_range_name[c[1] - '0'], (double)v);
        } else {
            console_printf("bad value\r\n");
        }
    } else if (!strcmp(c, "save")) {
        console_printf("%s\r\n", cal_save() == 0 ? "saved" : "flash write FAILED");
    } else if (!strcmp(c, "clear")) {
        cal_clear(lcr_get_freq());
        console_printf("calibration at this frequency cleared (save to make it permanent)\r\n");
    } else if (!strcmp(c, "stream")) {
        st->stream = !st->stream;
        if (st->stream) print_header();
    } else if (!strcmp(c, "cmp")) {
        st->cmp_phase = !st->cmp_phase;
        console_printf("comparator phase %s\r\n", st->cmp_phase ? "on" : "off");
    } else if (!strcmp(c, "info")) {
        print_info();
    } else {
        console_printf("? unknown: %s (type help)\r\n", c);
    }
}

void console_init(void)
{
    HAL_UART_Receive_IT(&huart2, &s_rx_byte, 1);
    print_help();
    print_info();
    print_header();
}

void console_poll(ui_state_t *st)
{
    while (s_tail != s_head) {
        char ch = (char)s_ring[s_tail];
        s_tail = (uint8_t)((s_tail + 1u) % sizeof s_ring);
        if (ch == '\r' || ch == '\n') {
            if (s_len > 0) {
                s_line[s_len] = '\0';
                s_len = 0;
                run_command(s_line, st);
            }
        } else if (s_len < sizeof s_line - 1) {
            s_line[s_len++] = ch;
        }
    }
}

void console_report(const lcr_result_t *r)
{
    char val[24];
    eng(val, sizeof val, r->value, r->kind == 'L' ? "H" : r->kind == 'C' ? "F" : "ohm", 0);
    console_printf("%.0f,%s,%.6g,%.4f,%.4f,%.5f,%.5f,%.6g,%.6g,%.6g,%.6g,%d,%s,%c,%s,%.4g,%.2f,%.2f\r\n",
                   (double)r->f_hz, g_range_name[r->range], (double)r->rref, (double)r->vs_pk, (double)r->vx_pk,
                   (double)crealf(r->H), (double)cimagf(r->H), (double)crealf(r->z_raw), (double)cimagf(r->z_raw),
                   (double)crealf(r->z), (double)cimagf(r->z), r->calibrated, lcr_status_text(r->status), r->kind,
                   r->status == ST_OK ? val : "-", (double)r->esr, (double)r->phase_deg, (double)r->phase_cmp_deg);
}
