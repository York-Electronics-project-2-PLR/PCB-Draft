/*
 * lcr.h - excitation, acquisition, impedance calculation and auto-ranging.
 */
#ifndef LCR_H
#define LCR_H

#include <complex.h>
#include "config.h"

typedef enum {
    ST_OK = 0,
    ST_NOSIG,     /* VS too small: excitation path broken */
    ST_CLIP,      /* an ADC input hit a rail */
    ST_HIGH,      /* |Z| too large for this range (|1-H| tiny) */
    ST_LOW,       /* |Z| too small for this range (|H| tiny) */
    ST_OPEN,      /* nothing connected (above Z_OPEN_OHM or above the 1M range) */
    ST_SHORT,     /* leads shorted (below Z_SHORT_OHM or below the 100R range) */
    ST_TIMEOUT    /* DMA did not finish */
} lcr_status_t;

typedef struct {
    int freq;                 /* index into FREQ_HZ_LIST */
    float f_hz;
    int range;                /* index into RREF / RANGE_NAME */
    float rref;               /* ohm, measured value from calib */
    float vs_pk, vx_pk;       /* fundamental amplitudes, V peak, relative to VMID */
    float complex H;          /* VX / VS */
    float complex z_raw;      /* Rref * H / (1 - H) */
    float complex z;          /* after open/short compensation */
    int calibrated;
    lcr_status_t status;
    char kind;                /* 'R', 'L' or 'C' when status == ST_OK */
    float value;              /* ohm, henry or farad */
    float esr;                /* Re(Z), ohm */
    float phase_deg;          /* arg(Z) */
    float phase_cmp_deg;      /* from the comparators (NAN if not measured) */
} lcr_result_t;

/* raw ADC codes of one block, for fault finding: index 0 = ADC1 (VS), 1 = ADC2 (VX or the DAC pin) */
typedef struct {
    unsigned min[2], max[2];
    float mean[2];            /* DC level, codes (2048 = 1.65 V) */
    float ampl[2];            /* amplitude of the test frequency, codes peak */
} lcr_diag_t;

extern const char *const g_range_name[NUM_RANGES];

void  lcr_init(void);                              /* tables, start the excitation */
void  lcr_set_freq(int freq);
int   lcr_get_freq(void);
float lcr_freq_hz(int freq);
void  lcr_measure_range(int range, lcr_result_t *r);   /* one range, raw + compensation, no decision */
void  lcr_measure(lcr_result_t *r, int forced_range);  /* forced_range < 0: auto-range */
const char *lcr_status_text(lcr_status_t s);
int   lcr_diag_block(int range, lcr_diag_t *d);        /* 0 = ok, -1 = ADC timeout */
int   lcr_diag_dac_pin(lcr_diag_t *d);                 /* d index 1 = the DAC pin PA4 */
int   lcr_diag_addr(int addr, lcr_diag_t *d);          /* any 4051 address 0..7 */

#endif
