/*
 * board.h - pin map and peripheral handles (NUCLEO-G431KB + LCR carrier RevC).
 * Pin map checked against eda_output/04_bom_gpio/GPIO_mapping_RevC_verified.csv.
 */
#ifndef BOARD_H
#define BOARD_H

#include "stm32g4xx_hal.h"

/* 4051 range multiplexers (U3 drive, U4 sense share the address lines) */
#define MUX_S0_PORT   GPIOB
#define MUX_S0_PIN    GPIO_PIN_5      /* CN4-14 */
#define MUX_S1_PORT   GPIOB
#define MUX_S1_PIN    GPIO_PIN_4      /* CN4-15 */
#define MUX_S2_PORT   GPIOA
#define MUX_S2_PIN    GPIO_PIN_1      /* CN3-11, R18 pull-down */
#define MUX_INH_PORT  GPIOB
#define MUX_INH_PIN   GPIO_PIN_7      /* CN4-7, high = both muxes off */

/* push button to GND, internal pull-up */
#define BTN_PORT      GPIOA
#define BTN_PIN       GPIO_PIN_15     /* CN4-8 */

/* LCD1602, 4-bit, write only (RW tied to GND) */
#define LCD_RS_PORT   GPIOA
#define LCD_RS_PIN    GPIO_PIN_10     /* CN4-2 */
#define LCD_E_PORT    GPIOA
#define LCD_E_PIN     GPIO_PIN_12     /* CN4-5 */
#define LCD_D4_PORT   GPIOB
#define LCD_D4_PIN    GPIO_PIN_6      /* CN4-9 */
#define LCD_D5_PORT   GPIOA
#define LCD_D5_PIN    GPIO_PIN_11     /* CN4-13 */
#define LCD_D6_PORT   GPIOB
#define LCD_D6_PIN    GPIO_PIN_0      /* CN4-6 */
#define LCD_D7_PORT   GPIOB
#define LCD_D7_PIN    GPIO_PIN_3      /* CN3-15 (SWO not available) */

/* analogue: PA4 DAC1_OUT1 (CN3-9), PA0 ADC1_IN1 = VS (CN3-12), PA7 ADC2_IN4 = VX (CN3-6)
 * comparators: PA8 TIM1_CH1 = PHASE_S (CN4-12), PA9 TIM1_CH2 = PHASE_X (CN4-1)
 * console: PA2 / PA3 USART2 = ST-LINK virtual COM port                      */

extern ADC_HandleTypeDef  hadc1, hadc2;
extern DAC_HandleTypeDef  hdac1;
extern DMA_HandleTypeDef  hdma_adc1, hdma_dac1;
extern TIM_HandleTypeDef  htim1, htim6;
extern UART_HandleTypeDef huart2;

void board_clock_init(void);
void board_init_pins(void);          /* GPIO + microsecond delay: enough for the LCD */
void board_init(void);               /* UART, DMA, timers, DAC, ADC (call after board_init_pins) */
void board_set_freq(int freq_idx);   /* TIM6 rate + ADC sampling time for that frequency */
void board_adc2_channel(uint32_t channel);   /* diagnostics only */
void board_mux(int addr, int enable);
int  board_button_down(void);
void delay_us(uint32_t us);
void board_error(const char *where);

#endif
