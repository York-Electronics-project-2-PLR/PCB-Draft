/*
 * config.h - build-time settings of the LCR meter (STM32G431 RevC hardware).
 *
 * Everything that depends on the board, the reference resistors or the
 * measurement method is collected here, so the rest of the code does not
 * need to be touched when a value changes.
 */
#ifndef CONFIG_H
#define CONFIG_H

/* Shown on the LCD and the console at power-up; change the number with every
 * new build so it is clear which program is in the board. Max 16 characters. */
#define FW_NAME             "LCR meter bb6"

/* ---------------------------------------------------------------- clocks */
#define SYSCLK_HZ           128000000UL   /* HSI16 -> PLL, see board.c; 128 MHz gives exact 1 kHz / 10 kHz */

/* ------------------------------------------------- excitation / sampling */
#define WAVE_N              64            /* DAC and ADC points per excitation period (power of 2) */
#define ACQ_PERIODS         16            /* excitation periods per DMA block */
#define ACQ_SAMPLES         (WAVE_N * ACQ_PERIODS)
#define DAC_MID             2048          /* 1.65 V = VMID */
#define DAC_AMPL            620           /* 0.50 V peak (spec section 08) */
#define ADC_VREF_V          3.3f
#define ADC_FULLSCALE       4095.0f

/* Test frequencies. TIM6 runs at SYSCLK and fires WAVE_N times per period:
 *   ARR = SYSCLK / (WAVE_N * f) - 1                                          */
#define NUM_FREQS           2
#define FREQ_HZ_LIST        { 1000.0f, 10000.0f }
#define FREQ_TIM6_ARR       { 1999u, 199u }
#define FREQ_REPS           { 2, 8 }      /* DMA blocks averaged per measurement */

/* ------------------------------------------------------------ ranges
 * Index order = increasing reference resistance.  ADDR = 4051 address S2 S1 S0
 * (schematic P2: 000 = 1k, 001 = 10k, 010 = 47k, 011 = 100R, 100 = 1M).
 * RREF_NOMINAL is only the starting point: measure every reference resistor
 * with a >= 4.5 digit meter and store the real value over the serial console
 * ("r2=9987.4" then "w"), so no rebuild is needed.                          */
#define NUM_RANGES          5
#define RREF_NOMINAL        { 100.0f, 1000.0f, 10000.0f, 47000.0f, 1000000.0f }
#define RANGE_ADDR          { 3, 0, 1, 2, 4 }
#define RANGE_NAME          { "100R", "1k", "10k", "47k", "1M" }
#define RANGE_SETTLE_MS     { 10, 10, 20, 40, 150 }   /* wait after switching (tune on the bench) */
#define START_RANGE         2                         /* 10k */

/* ------------------------------------------------------- decision limits */
#define MIN_VS_PEAK_V       0.05f   /* VS smaller than this: no drive (DAC / U1 / R5 / mux problem) */
#define CLIP_LO             8       /* ADC codes this close to the rails count as clipping */
#define CLIP_HI             4087
#define H_EDGE              0.02f   /* |H| or |1-H| below this: |Z| is >50x away from Rref */
#define H_EDGE_CAL          0.002f  /* looser limit accepted while recording open/short calibration */
#define RANGE_HYST_DEC      0.35f   /* change range only if |log10(|Z|/Rref)| improves by this much */
#define REACTIVE_MIN        0.10f   /* |X| < 0.1 |Z|  -> reported as a resistor */
#define Z_OPEN_OHM          20.0e6f /* above this: nothing connected */
#define Z_SHORT_OHM         0.5f    /* below this: leads shorted */

/* -------------------------------------------------------------- user I/O */
#define BTN_LONG_MS         1500    /* hold this long for the calibration wizard */
#define UART_BAUD           115200  /* ST-LINK virtual COM port (USART2, PA2/PA3) */

/* ---------------------------------------------------- calibration storage */
#define CAL_FLASH_ADDR      0x0801F800UL   /* last 2 KB page of the 128 KB flash; linker script stops before it */
#define CAL_FLASH_PAGE      63u

#endif
