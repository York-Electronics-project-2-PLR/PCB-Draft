/*
 * ui.h - LCD screens, push button, serial console.
 */
#ifndef UI_H
#define UI_H

#include "lcr.h"

typedef enum { BTN_NONE, BTN_SHORT, BTN_LONG } btn_event_t;

typedef struct {
    int forced_range;      /* -1 = auto */
    int stream;            /* print one CSV line per measurement */
    int cmp_phase;         /* also measure the comparator phase */
} ui_state_t;

void ui_splash(void);
void ui_show(const lcr_result_t *r);
btn_event_t ui_button(void);             /* returns and clears the pending button event */
void ui_button_tick(void);                /* call every 1 ms (SysTick): debounce + press length */
void ui_cal_wizard(void);                 /* open + short calibration on the current frequency */

void console_init(void);
void console_poll(ui_state_t *st);        /* handles complete command lines */
void console_report(const lcr_result_t *r);
void console_printf(const char *fmt, ...);

#endif
