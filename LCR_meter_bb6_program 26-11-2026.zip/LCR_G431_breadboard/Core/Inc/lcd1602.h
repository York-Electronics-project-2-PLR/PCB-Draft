/*
 * lcd1602.h - HD44780-compatible 16x2 LCD, 4-bit bus, write only.
 */
#ifndef LCD1602_H
#define LCD1602_H

/* custom characters loaded into CGRAM (same on every ROM variant) */
#define LCD_OHM  "\x01"
#define LCD_MU   "\x02"
#define LCD_DEG  "\x03"

void lcd_init(void);
int  lcd_ready(void);                       /* 1 once lcd_init() has finished */
void lcd_clear(void);
void lcd_line(int row, const char *text);   /* writes the whole row, pads with spaces */

#endif
