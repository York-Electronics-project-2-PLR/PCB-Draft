/*
 * calib.h - measured reference resistors and open/short compensation,
 * kept in the last flash page so they survive power cycles.
 */
#ifndef CALIB_H
#define CALIB_H

#include <complex.h>
#include "config.h"

void  cal_init(void);                       /* load from flash, or defaults */
int   cal_save(void);                       /* 0 = ok */
float cal_rref(int range);
void  cal_set_rref(int range, float ohm);
void  cal_set_open(int freq, int range, float complex z, int valid);
void  cal_set_short(int freq, int range, float complex z, int valid);
void  cal_clear(int freq);
int   cal_flags(int freq, int range);       /* bit0 open valid, bit1 short valid */
float complex cal_apply(int freq, int range, float complex zm, int *applied);
int   cal_loaded_from_flash(void);

#endif
