/*
 * phase_cmp.h - phase from the TLV3202 zero-crossing comparators (TIM1 capture).
 * Independent cross-check of the ADC phase; not used for the displayed value.
 */
#ifndef PHASE_CMP_H
#define PHASE_CMP_H

#include <stdint.h>

/* phi = wrap(2 pi (tS - tX) / T), degrees in (-180, 180]; VX lagging VS is negative.
 * Returns NAN if the comparators produce no usable edges within timeout_ms. */
float phase_cmp_measure_deg(int periods, uint32_t timeout_ms);

#endif
