# Build without GNU make: same sources and flags as the Makefile.
#   python build.py            -> build/lcr_g431.elf, .hex, .bin
#   python build.py clean
# The compiler is found on PATH, or in the folder named by the environment variable ARM_GCC_BIN,
# or in the default folder below (portable xPack GNU Arm Embedded GCC).
import os, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
TARGET, BUILD = 'lcr_g431', 'build'
DEFAULT_BIN = r'C:\Users\64189\tools\arm-gcc\xpack-arm-none-eabi-gcc-15.2.1-1.1\bin'

def tool(name):
    for d in (os.environ.get('ARM_GCC_BIN'), DEFAULT_BIN):
        if d and os.path.exists(os.path.join(d, name + '.exe')):
            return os.path.join(d, name + '.exe')
    found = shutil.which(name)
    if not found:
        sys.exit('cannot find %s: set ARM_GCC_BIN to the bin folder of the Arm GNU toolchain' % name)
    return found

HAL = 'Drivers/STM32G4xx_HAL_Driver/Src/'
C_SOURCES = ['Core/Src/' + f for f in ('main.c', 'board.c', 'lcr.c', 'calib.c', 'lcd1602.c', 'phase_cmp.c', 'ui.c',
                                       'stm32g4xx_it.c', 'system_stm32g4xx.c')] + \
            [HAL + 'stm32g4xx_hal' + s + '.c' for s in ('', '_cortex', '_rcc', '_rcc_ex', '_pwr', '_pwr_ex', '_gpio', '_exti',
                                                        '_dma', '_dma_ex', '_adc', '_adc_ex', '_dac', '_dac_ex', '_tim', '_tim_ex',
                                                        '_uart', '_uart_ex', '_flash', '_flash_ex', '_flash_ramfunc')]
ASM_SOURCES = ['Core/Startup/startup_stm32g431xx.s']

MCU = ['-mcpu=cortex-m4', '-mthumb', '-mfpu=fpv4-sp-d16', '-mfloat-abi=hard']
DEFS = ['-DSTM32G431xx', '-DUSE_HAL_DRIVER']
INCS = ['-ICore/Inc', '-IDrivers/STM32G4xx_HAL_Driver/Inc', '-IDrivers/CMSIS/Device/ST/STM32G4xx/Include', '-IDrivers/CMSIS/Include']
CFLAGS = MCU + DEFS + INCS + ['-std=gnu11', '-O2', '-g3', '-Wall', '-Wextra', '-Wno-unused-parameter',
                              '-ffunction-sections', '-fdata-sections', '-fsingle-precision-constant']
LDFLAGS = MCU + ['-TSTM32G431KBTX_FLASH.ld', '--specs=nano.specs', '--specs=nosys.specs', '-u', '_printf_float',
                 '-Wl,--gc-sections', '-Wl,-Map=%s/%s.map' % (BUILD, TARGET), '-Wl,--print-memory-usage', '-lm']

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    return p.returncode, (p.stdout + p.stderr).strip()

def main():
    if sys.argv[1:] == ['clean']:
        shutil.rmtree(BUILD, ignore_errors=True)
        return
    os.makedirs(BUILD, exist_ok=True)
    cc, objcopy, size = tool('arm-none-eabi-gcc'), tool('arm-none-eabi-objcopy'), tool('arm-none-eabi-size')
    jobs = []
    for src in C_SOURCES:
        obj = '%s/%s.o' % (BUILD, os.path.splitext(os.path.basename(src))[0])
        jobs.append((src, obj, [cc, '-c'] + CFLAGS + [src, '-o', obj]))
    for src in ASM_SOURCES:
        obj = '%s/%s.o' % (BUILD, os.path.splitext(os.path.basename(src))[0])
        jobs.append((src, obj, [cc, '-c'] + MCU + ['-x', 'assembler-with-cpp', src, '-o', obj]))
    failed = 0
    with ThreadPoolExecutor(max_workers=os.cpu_count() or 4) as ex:
        for (src, obj, cmd), (rc, out) in zip(jobs, ex.map(lambda j: run(j[2]), jobs)):
            if out and (rc != 0 or src.startswith('Core/')):      # show warnings of our own code only
                print('--- %s\n%s' % (src, out))
            failed += rc != 0
    if failed:
        sys.exit('%d file(s) failed to compile' % failed)
    elf = '%s/%s.elf' % (BUILD, TARGET)
    rc, out = run([cc] + [j[1] for j in jobs] + LDFLAGS + ['-o', elf])
    # newlib's "nosys" stubs (_close, _read, ...) are never called by this program: hide those standard notes
    noise = ('is not implemented and will always fail', 'does not take linker garbage collection', 'in function `_', 'RWX permissions')
    print('\n'.join(l for l in out.splitlines() if rc != 0 or not any(n in l for n in noise)))
    if rc != 0:
        sys.exit('link failed')
    run([objcopy, '-O', 'ihex', elf, '%s/%s.hex' % (BUILD, TARGET)])
    run([objcopy, '-O', 'binary', '-S', elf, '%s/%s.bin' % (BUILD, TARGET)])
    print(run([size, elf])[1])
    print('OK: %s/%s.bin (%d bytes)' % (BUILD, TARGET, os.path.getsize('%s/%s.bin' % (BUILD, TARGET))))

main()
